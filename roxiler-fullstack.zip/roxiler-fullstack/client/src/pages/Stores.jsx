import React, { useEffect, useState } from 'react';
import api from '../api';

export default function Stores() {
  const [stores, setStores] = useState([]);

  useEffect(() => {
    api.get('/stores')
      .then(res => setStores(res.data.stores))
      .catch(err => alert(err.response?.data?.message || 'Error fetching stores'));
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h2>Stores</h2>
      <ul>
        {stores.map(s => (
          <li key={s.id}>
            <b>{s.name}</b> ({s.address})  
            <br />Overall Rating: {s.overallRating} ⭐
            <br />Your Rating: {s.yourRating || 'N/A'}
          </li>
        ))}
      </ul>
    </div>
  );
}
