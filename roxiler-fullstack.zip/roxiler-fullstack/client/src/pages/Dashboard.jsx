import React, { useEffect, useState } from 'react';
import api from '../api';

export default function Dashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    api.get('/admin/dashboard')
      .then(res => setData(res.data))
      .catch(() => setData({ error: 'Not an admin or unauthorized' }));
  }, []);

  if (!data) return <p>Loading...</p>;

  return (
    <div style={{ padding: '20px' }}>
      <h2>Dashboard</h2>
      {data.error ? (
        <p>{data.error}</p>
      ) : (
        <ul>
          <li>Total Users: {data.totalUsers}</li>
          <li>Total Stores: {data.totalStores}</li>
          <li>Total Ratings: {data.totalRatings}</li>
        </ul>
      )}
    </div>
  );
}
