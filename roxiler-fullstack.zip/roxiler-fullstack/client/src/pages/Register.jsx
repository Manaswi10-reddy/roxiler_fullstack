import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';

export default function Register() {
  const [form, setForm] = useState({ name: '', email: '', address: '', password: '' });
  const navigate = useNavigate();

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post('/auth/register', form);
      localStorage.setItem('token', res.data.token);
      navigate('/');
    } catch (err) {
      alert(err.response?.data?.message || 'Register failed');
    }
  };

  return (
    <form onSubmit={handleRegister} style={{ padding: '20px' }}>
      <h2>Register</h2>
      <input name="name" placeholder="Full Name" value={form.name} onChange={handleChange} /><br />
      <input name="email" placeholder="Email" value={form.email} onChange={handleChange} /><br />
      <input name="address" placeholder="Address" value={form.address} onChange={handleChange} /><br />
      <input name="password" type="password" placeholder="Password" value={form.password} onChange={handleChange} /><br />
      <button type="submit">Register</button>
    </form>
  );
}
