// app.js
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const { sequelize, User, Store, Rating } = require('./models');

const app = express();
app.use(bodyParser.json());

const JWT_SECRET = process.env.JWT_SECRET || 'supersecretkey';
const PORT = process.env.PORT || 4000;

/* ---------- helpers / middleware ---------- */

function generateToken(user) {
  return jwt.sign({
    id: user.id,
    email: user.email,
    role: user.role
  }, JWT_SECRET, { expiresIn: '8h' });
}

async function authMiddleware(req, res, next) {
  try {
    const auth = req.headers['authorization'];
    if (!auth) return res.status(401).json({ message: 'Missing auth token' });
    const token = auth.split(' ')[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findByPk(decoded.id);
    if (!user) return res.status(401).json({ message: 'Invalid token (user not found)' });
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Unauthorized', error: err.message });
  }
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Unauthorized' });
    if (!roles.includes(req.user.role)) return res.status(403).json({ message: 'Forbidden - insufficient role' });
    next();
  };
}

/* ---------- validations ---------- */

function validatePassword(password) {
  if (!password) return false;
  const len = password.length;
  if (len < 8 || len > 16) return false;
  // at least one uppercase and one special character
  if (!/[A-Z]/.test(password)) return false;
  if (!/[^\w\s]/.test(password)) return false;
  return true;
}

function validateName(name) {
  if (!name) return false;
  const len = name.trim().length;
  return len >= 20 && len <= 60;
}

/* ---------- auth routes ---------- */

// Register (normal user)
app.post('/auth/register', async (req, res) => {
  try {
    const { name, email, address, password } = req.body;
    if (!validateName(name)) return res.status(400).json({ message: 'Name must be 20-60 characters' });
    if (!validatePassword(password)) return res.status(400).json({ message: 'Password 8-16 chars, 1 uppercase, 1 special char required' });
    if (!email) return res.status(400).json({ message: 'Email required' });

    const existing = await User.findOne({ where: { email } });
    if (existing) return res.status(400).json({ message: 'Email already exists' });

    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, address, password: hashed, role: 'normal' });
    const token = generateToken(user);
    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Login
app.post('/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Email and password required' });
    const user = await User.findOne({ where: { email } });
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(401).json({ message: 'Invalid credentials' });
    const token = generateToken(user);
    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Update password (any authenticated user)
app.put('/auth/password', authMiddleware, async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;
    if (!validatePassword(newPassword)) return res.status(400).json({ message: 'New password invalid' });
    const ok = await bcrypt.compare(oldPassword, req.user.password);
    if (!ok) return res.status(400).json({ message: 'Old password incorrect' });
    const hashed = await bcrypt.hash(newPassword, 10);
    req.user.password = hashed;
    await req.user.save();
    res.json({ message: 'Password updated' });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

/* ---------- Admin routes (System Administrator) ---------- */

// Create user (admin)
app.post('/admin/users', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const { name, email, password, address, role } = req.body;
    if (!validateName(name)) return res.status(400).json({ message: 'Name must be 20-60 characters' });
    if (!validatePassword(password)) return res.status(400).json({ message: 'Password invalid' });
    if (!email) return res.status(400).json({ message: 'Email required' });
    if (!['admin','normal','store_owner'].includes(role)) return res.status(400).json({ message: 'Invalid role' });

    const existing = await User.findOne({ where: { email } });
    if (existing) return res.status(400).json({ message: 'Email already exists' });
    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, address, password: hashed, role });
    res.json({ message: 'User created', user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Create store (admin)
app.post('/admin/stores', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const { name, email, address, ownerId } = req.body;
    if (!name) return res.status(400).json({ message: 'Store name required' });
    // ownerId optional (assign to a store_owner user)
    if (ownerId) {
      const owner = await User.findByPk(ownerId);
      if (!owner || owner.role !== 'store_owner') return res.status(400).json({ message: 'ownerId must be a store_owner user' });
    }
    const store = await Store.create({ name, email, address, ownerId: ownerId || null });
    res.json({ message: 'Store created', store });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Admin dashboard
app.get('/admin/dashboard', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const totalUsers = await User.count();
    const totalStores = await Store.count();
    const totalRatings = await Rating.count();
    res.json({ totalUsers, totalStores, totalRatings });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin: list users (with filters & sorting)
app.get('/admin/users', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const { name, email, address, role, sortBy='name', order='ASC', limit=50, offset=0 } = req.query;
    const where = {};
    if (name) where.name = { [sequelize.Op.like]: `%${name}%` };
    if (email) where.email = { [sequelize.Op.like]: `%${email}%` };
    if (address) where.address = { [sequelize.Op.like]: `%${address}%` };
    if (role) where.role = role;
    const users = await User.findAll({ where, order: [[sortBy, order.toUpperCase()]], limit: parseInt(limit), offset: parseInt(offset) });
    res.json({ users });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Admin: list stores (with filters & sorting) and their overall rating
app.get('/admin/stores', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const { name, email, address, sortBy='name', order='ASC', limit=50, offset=0 } = req.query;
    const where = {};
    if (name) where.name = { [sequelize.Op.like]: `%${name}%` };
    if (email) where.email = { [sequelize.Op.like]: `%${email}%` };
    if (address) where.address = { [sequelize.Op.like]: `%${address}%` };

    const stores = await Store.findAll({ where, order: [[sortBy, order.toUpperCase()]], limit: parseInt(limit), offset: parseInt(offset), include: [{ model: User, as: 'Owner', attributes: ['id','name','email','role'] }] });

    // attach average rating
    const result = await Promise.all(stores.map(async s => {
      const stats = await Rating.findAll({ where: { StoreId: s.id }, attributes: [[sequelize.fn('AVG', sequelize.col('rating')), 'avgRating']] });
      const avg = stats && stats.length ? parseFloat(stats[0].dataValues.avgRating || 0).toFixed(2) : '0.00';
      return { store: s, averageRating: Number(avg) };
    }));
    res.json({ stores: result });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Admin: view a user's details
app.get('/admin/users/:id', authMiddleware, requireRole('admin'), async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id, { include: [{ model: Store, as: 'OwnedStore' }] });
    if (!user) return res.status(404).json({ message: 'User not found' });

    // if store owner, include rating
    let rating = null;
    if (user.role === 'store_owner' && user.OwnedStore) {
      const stats = await Rating.findAll({ where: { StoreId: user.OwnedStore.id }, attributes: [[sequelize.fn('AVG', sequelize.col('rating')), 'avgRating']] });
      rating = stats && stats.length ? parseFloat(stats[0].dataValues.avgRating || 0).toFixed(2) : null;
    }

    res.json({ user: { id: user.id, name: user.name, email: user.email, address: user.address, role: user.role, store: user.OwnedStore || null, storeRating: rating } });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

/* ---------- Normal user routes ---------- */

// List all stores (with search by name/address), includes overall rating and user's submitted rating (if authenticated)
app.get('/stores', authMiddleware, async (req, res) => {
  try {
    // any authenticated user (both normal and store owner) can view store list
    const { name, address, sortBy='name', order='ASC', limit=50, offset=0 } = req.query;
    const where = {};
    if (name) where.name = { [sequelize.Op.like]: `%${name}%` };
    if (address) where.address = { [sequelize.Op.like]: `%${address}%` };
    const stores = await Store.findAll({ where, order: [[sortBy, order.toUpperCase()]], limit: parseInt(limit), offset: parseInt(offset) });

    const result = await Promise.all(stores.map(async s => {
      const avgRow = await Rating.findAll({ where: { StoreId: s.id }, attributes: [[sequelize.fn('AVG', sequelize.col('rating')), 'avgRating']] });
      const avg = avgRow && avgRow.length ? parseFloat(avgRow[0].dataValues.avgRating || 0).toFixed(2) : '0.00';
      const userRatingRow = await Rating.findOne({ where: { StoreId: s.id, UserId: req.user.id } });
      return {
        id: s.id,
        name: s.name,
        address: s.address,
        overallRating: Number(avg),
        yourRating: userRatingRow ? userRatingRow.rating : null
      };
    }));

    res.json({ stores: result });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Submit rating for a store
app.post('/stores/:id/rate', authMiddleware, requireRole('normal'), async (req, res) => {
  try {
    const store = await Store.findByPk(req.params.id);
    if (!store) return res.status(404).json({ message: 'Store not found' });
    const { rating } = req.body;
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) return res.status(400).json({ message: 'Rating must be integer 1-5' });

    // check if already rated
    const existing = await Rating.findOne({ where: { UserId: req.user.id, StoreId: store.id } });
    if (existing) return res.status(400).json({ message: 'You have already rated this store. Use PUT to modify.' });

    const r = await Rating.create({ rating, UserId: req.user.id, StoreId: store.id });
    res.json({ message: 'Rating submitted', rating: r });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Modify submitted rating
app.put('/stores/:id/rate', authMiddleware, requireRole('normal'), async (req, res) => {
  try {
    const store = await Store.findByPk(req.params.id);
    if (!store) return res.status(404).json({ message: 'Store not found' });
    const { rating } = req.body;
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) return res.status(400).json({ message: 'Rating must be integer 1-5' });

    const existing = await Rating.findOne({ where: { UserId: req.user.id, StoreId: store.id } });
    if (!existing) return res.status(404).json({ message: 'Rating not found. Submit one first.' });

    existing.rating = rating;
    await existing.save();
    res.json({ message: 'Rating updated', rating: existing });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

/* ---------- Store owner routes ---------- */

// Owner dashboard: view list of users who rated their store and average rating
app.get('/owner/dashboard', authMiddleware, requireRole('store_owner'), async (req, res) => {
  try {
    const store = await Store.findOne({ where: { ownerId: req.user.id } });
    if (!store) return res.status(404).json({ message: 'No store assigned to this owner' });

    const ratings = await Rating.findAll({ where: { StoreId: store.id }, include: [{ model: User, attributes: ['id','name','email']}], order: [['createdAt', 'DESC']] });
    const avgRow = await Rating.findAll({ where: { StoreId: store.id }, attributes: [[sequelize.fn('AVG', sequelize.col('rating')), 'avgRating']] });
    const avg = avgRow && avgRow.length ? parseFloat(avgRow[0].dataValues.avgRating || 0).toFixed(2) : '0.00';

    res.json({ store: { id: store.id, name: store.name, address: store.address }, averageRating: Number(avg), ratings });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

/* ---------- Misc ---------- */

app.get('/', (req, res) => res.json({ message: 'Roxiler assignment backend running' }));

/* ---------- DB sync and server start ---------- */

async function start() {
  try {
    await sequelize.authenticate();
    // sync models (in dev, you can use { force: true } but be careful)
    await sequelize.sync({ alter: true });
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  } catch (err) {
    console.error('Unable to start server:', err);
  }
}

start();
