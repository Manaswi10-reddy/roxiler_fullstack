// models.js
const { DataTypes } = require('sequelize');
const sequelize = require('./db');

const User = sequelize.define('User', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  name: { type: DataTypes.STRING(60), allowNull: false },
  email: { type: DataTypes.STRING(120), allowNull: false, unique: true },
  password: { type: DataTypes.STRING(255), allowNull: false },
  address: { type: DataTypes.STRING(400), allowNull: true },
  role: { type: DataTypes.ENUM('admin','normal','store_owner'), allowNull: false, defaultValue: 'normal' }
}, { timestamps: true });

const Store = sequelize.define('Store', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  name: { type: DataTypes.STRING(120), allowNull: false },
  email: { type: DataTypes.STRING(120), allowNull: true },
  address: { type: DataTypes.STRING(400), allowNull: true }
}, { timestamps: true });

const Rating = sequelize.define('Rating', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  rating: { type: DataTypes.INTEGER, allowNull: false, validate: { min: 1, max: 5 } }
}, { timestamps: true });

// Associations
// A User may own a Store (one-to-one optional)
User.hasOne(Store, { as: 'OwnedStore', foreignKey: 'ownerId' });
Store.belongsTo(User, { as: 'Owner', foreignKey: 'ownerId' });

// Ratings: user <-> store many-to-many through Rating
User.hasMany(Rating);
Rating.belongsTo(User);

Store.hasMany(Rating);
Rating.belongsTo(Store);

module.exports = {
  sequelize,
  User,
  Store,
  Rating
};
